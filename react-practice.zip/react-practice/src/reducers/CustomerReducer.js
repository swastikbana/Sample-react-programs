export default function reducer(state={
    customer: {
      firstName: null,
      dob: null,
      country: null,
      gender: null,
      fmlybook: null,
      emId: null,
      residence :null,
      custImg: null,
      email: null,
      phNum: null,
      address: null,
      poBox: null,
      city: null,
      district: null,
      region: null,
      website: null,
    },
    fetching: false,
    fetched: false,
    error: null,
  }, action) {

    switch (action.type) {
      case "FETCH_COSTOMER_DETAILS_INITIATED": {
        return {state, fetching: true}
      }
      case "FETCH_COSTOMER_DETAILS_REJECTED": {
        return {state, fetching: false, error: action.payload}
      }
      case "FETCH_COSTOMER_DETAILS_FULFILLED": {
        return {
          state,
          fetching: false,
          fetched: true,
          customer: action.payload,
        }
      }
    }

    return state
}