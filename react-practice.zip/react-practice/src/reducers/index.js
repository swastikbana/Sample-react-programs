import { combineReducers } from "redux"

import customerInteractionData from "./CustomerReducer"
import customer from "./customerReducer";

export default combineReducers({
  customer,
})
