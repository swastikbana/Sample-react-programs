import React from 'react';
import {render} from 'react-dom';
import { Provider } from "react-redux";
import store from "./store";
import { fetchCustomerDetails } from '../../actions/CustomerDetails';
import { connect } from "react-redux";

connect((store) => {
    return {
        customer: store.customer.customer,
    };
})
class App extends React.Component {

 componentDidMount() {
        console.log(" Start componentDidMount function")
        this.fetchlocalCustomerDetails();
        console.log("End componentDidMount function")
    }
    fetchlocalCustomerDetails() {
        this.props.dispatch(fetchCustomerDetails())
    }

render () {
    const { customer, userFetched } = this.props;
return <div>
    <p>Hello {this.props.check}</p>
      <p>Customer name :  {customer}</p>
    <button>Click</button>
</div>
}
}

render(
 <Provider store={store}>
    <App check="Nandini"/> 
</Provider>, document.getElementById('app'));