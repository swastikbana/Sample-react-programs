import axios from "axios";


export function fetchCustomerDetails() {
  console.log("getting customer details");
  return function(dispatch) {
    axios.get("http://localhost:9090/DS360Auth_Demo/rest/UserInfoService/customerData")
      .then((response) => {
        dispatch({type: "FETCH_COSTOMER_DETAILS_FULFILLED", payload: response.data})
      })
      .catch((err) => {
        dispatch({type: "FETCH_COSTOMER_DETAILS_REJECTED", payload: err})
      })
  }
  console.log("getting customer details return");
}